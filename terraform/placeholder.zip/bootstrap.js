exports.handler = async (event) => {
    console.log("Bootstrap Lambda executed", event);

    return {
        statusCode: 200,
        body: JSON.stringify({
            message: "bootstrap ready",
        }),
    };
};